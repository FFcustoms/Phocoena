// SPDX-License-Identifier: GPL-2.0-or-later
#include "Horizon/SupportDiagnostics.h"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include "Horizon/BuildInfo.h"
#include "Horizon/Log.h"

#include <mz.h>
#include <mz_strm.h>
#include <mz_zip.h>
#include <mz_zip_rw.h>

namespace Horizon
{
namespace
{
namespace fs = std::filesystem;

struct ActiveSession
{
  fs::path dir;
  std::string id;
  std::time_t started_epoch = 0;
  std::chrono::steady_clock::time_point started_mono{};
  SupportSessionMetadata metadata;
  bool active = false;
};

ActiveSession s_session;

fs::path DiagnosticsRoot()
{
  return fs::path(ROOT) / "diagnostics";
}
fs::path SessionsRoot()
{
  return DiagnosticsRoot() / "sessions";
}
fs::path BundlesRoot()
{
  return DiagnosticsRoot() / "bundles";
}
fs::path ActiveMarker()
{
  return DiagnosticsRoot() / "active-session.txt";
}

std::string Sanitize(std::string value)
{
  for (char& c : value)
  {
    const unsigned char u = static_cast<unsigned char>(c);
    if (!(std::isalnum(u) || c == '-' || c == '_' || c == '.'))
      c = '_';
  }
  if (value.empty())
    value = "unknown";
  if (value.size() > 64)
    value.resize(64);
  return value;
}

std::string JsonEscape(std::string_view value)
{
  std::string out;
  out.reserve(value.size() + 16);
  for (unsigned char c : value)
  {
    switch (c)
    {
    case '\\': out += "\\\\"; break;
    case '"': out += "\\\""; break;
    case '\n': out += "\\n"; break;
    case '\r': out += "\\r"; break;
    case '\t': out += "\\t"; break;
    default:
      if (c < 0x20)
      {
        char temp[7];
        std::snprintf(temp, sizeof(temp), "\\u%04x", c);
        out += temp;
      }
      else
      {
        out += static_cast<char>(c);
      }
      break;
    }
  }
  return out;
}

bool WriteTextAtomic(const fs::path& path, const std::string& text)
{
  std::error_code ec;
  fs::create_directories(path.parent_path(), ec);
  if (ec)
    return false;
  const fs::path temp = path.string() + ".tmp";
  {
    std::ofstream stream(temp, std::ios::binary | std::ios::trunc);
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    stream.flush();
    if (!stream)
      return false;
  }
  fs::remove(path, ec);
  ec.clear();
  fs::rename(temp, path, ec);
  return !ec;
}

std::string ReadKey(const fs::path& file, std::string_view wanted)
{
  std::ifstream stream(file);
  std::string line;
  const std::string prefix = std::string(wanted) + "=";
  while (std::getline(stream, line))
  {
    if (!line.empty() && line.back() == '\r')
      line.pop_back();
    if (line.starts_with(prefix))
      return line.substr(prefix.size());
  }
  return {};
}

std::string ReadText(const fs::path& file)
{
  std::ifstream stream(file, std::ios::binary);
  return {std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()};
}

std::string RecoveredSummary(std::string summary)
{
  const std::string running = "\"status\": \"running\"";
  if (const std::size_t pos = summary.find(running); pos != std::string::npos)
    summary.replace(pos, running.size(), "\"status\": \"abnormal_exit\"");
  const std::string close = "\n}\n";
  if (const std::size_t pos = summary.rfind(close); pos != std::string::npos)
  {
    summary.insert(pos, ",\n  \"recovered_on_next_launch\": true,\n"
                        "  \"recovery_note\": \"Phocoena did not finalize this session before the next launch.\"");
  }
  return summary;
}

std::string SummaryJson(std::string_view status, double guest_ms, std::string_view last_error,
                        std::int64_t wall_ms)
{
  const auto& m = s_session.metadata;
  std::ostringstream out;
  out << "{\n"
      << "  \"session_id\": \"" << JsonEscape(s_session.id) << "\",\n"
      << "  \"phocoena_version\": \"" << JsonEscape(DOLPHIN_PORT_VERSION) << "\",\n"
      << "  \"upstream_commit\": \"" << JsonEscape(DOLPHIN_UPSTREAM_COMMIT) << "\",\n"
      << "  \"game_id\": \"" << JsonEscape(m.game_id) << "\",\n"
      << "  \"game_name\": \"" << JsonEscape(m.game_name) << "\",\n"
      << "  \"renderer\": \"" << JsonEscape(m.renderer) << "\",\n"
      << "  \"cpu_mode\": \"" << JsonEscape(m.cpu_mode) << "\",\n"
      << "  \"shader_mode\": \"" << JsonEscape(m.shader_mode) << "\",\n"
      << "  \"fifo_blocks\": " << m.fifo_blocks << ",\n"
      << "  \"requested_cpu_hz\": " << m.requested_cpu_hz << ",\n"
      << "  \"requested_gpu_hz\": " << m.requested_gpu_hz << ",\n"
      << "  \"selected_cpu_hz\": " << m.selected_cpu_hz << ",\n"
      << "  \"selected_gpu_hz\": " << m.selected_gpu_hz << ",\n"
      << "  \"effective_cpu_hz\": " << m.effective_cpu_hz << ",\n"
      << "  \"effective_gpu_hz\": " << m.effective_gpu_hz << ",\n"
      << "  \"effective_memory_hz\": " << m.effective_memory_hz << ",\n"
      << "  \"effective_cpu_valid\": " << (m.effective_cpu_valid ? "true" : "false") << ",\n"
      << "  \"effective_gpu_valid\": " << (m.effective_gpu_valid ? "true" : "false") << ",\n"
      << "  \"effective_memory_valid\": " << (m.effective_memory_valid ? "true" : "false") << ",\n"
      << "  \"clock_mechanism\": \"" << JsonEscape(m.clock_mechanism) << "\",\n"
      << "  \"external_clock_manager\": \"" << JsonEscape(m.external_clock_manager) << "\",\n"
      << "  \"memory_clock_written\": " << (m.memory_clock_written ? "true" : "false") << ",\n"
      << "  \"started_epoch\": " << static_cast<long long>(s_session.started_epoch) << ",\n"
      << "  \"wall_ms\": " << wall_ms << ",\n"
      << "  \"guest_ms\": " << guest_ms << ",\n"
      << "  \"status\": \"" << JsonEscape(status) << "\",\n"
      << "  \"last_error\": \"" << JsonEscape(last_error) << "\"\n"
      << "}\n";
  return out.str();
}

std::int64_t CurrentWallMs()
{
  if (!s_session.active)
    return 0;
  return std::chrono::duration_cast<std::chrono::milliseconds>(
             std::chrono::steady_clock::now() - s_session.started_mono)
      .count();
}

void CopyIfUseful(const fs::path& source, const fs::path& destination)
{
  std::error_code ec;
  if (!fs::is_regular_file(source, ec) || fs::file_size(source, ec) == 0)
    return;
  fs::copy_file(source, destination, fs::copy_options::overwrite_existing, ec);
}

bool AddZipFile(void* writer, const fs::path& disk_path, std::string archive_path)
{
  std::replace(archive_path.begin(), archive_path.end(), '\\', '/');
  return mz_zip_writer_add_file(writer, disk_path.string().c_str(), archive_path.c_str()) == MZ_OK;
}
}

void RecoverInterruptedSupportSession()
{
  std::error_code ec;
  fs::create_directories(SessionsRoot(), ec);
  fs::create_directories(BundlesRoot(), ec);
  if (!fs::is_regular_file(ActiveMarker(), ec))
    return;

  const std::string relative = ReadKey(ActiveMarker(), "session_dir");
  if (!relative.empty())
  {
    const fs::path dir = DiagnosticsRoot() / relative;
    const fs::path summary = dir / "summary.json";
    const std::string prior_summary = ReadText(summary);
    if (!prior_summary.empty())
      WriteTextAtomic(summary, RecoveredSummary(prior_summary));
    else
      WriteTextAtomic(summary, "{\n  \"status\": \"abnormal_exit\",\n  \"recovered_on_next_launch\": true\n}\n");
    std::ofstream event(dir / "events.log", std::ios::binary | std::ios::app);
    event << "abnormal_exit recovered on next Phocoena launch\n";
  }
  fs::remove(ActiveMarker(), ec);
}

bool BeginSupportSession(const SupportSessionMetadata& metadata, std::string* error)
{
  if (s_session.active)
    EndSupportSession("superseded", 0.0, "new session started before previous session finalized");

  std::error_code ec;
  fs::create_directories(SessionsRoot(), ec);
  if (ec)
  {
    if (error) *error = ec.message();
    return false;
  }

  s_session = {};
  s_session.metadata = metadata;
  s_session.started_epoch = std::time(nullptr);
  s_session.started_mono = std::chrono::steady_clock::now();
  const auto tick = static_cast<unsigned long long>(
      std::chrono::steady_clock::now().time_since_epoch().count() & 0xffffff);
  s_session.id = std::to_string(static_cast<long long>(s_session.started_epoch)) + "-" +
                 Sanitize(metadata.game_id.empty() ? "EXEC" : metadata.game_id) + "-" +
                 std::to_string(tick);
  s_session.dir = SessionsRoot() / s_session.id;
  fs::create_directories(s_session.dir, ec);
  if (ec)
  {
    if (error) *error = ec.message();
    s_session = {};
    return false;
  }
  s_session.active = true;

  WriteTextAtomic(s_session.dir / "summary.json", SummaryJson("running", 0.0, "", 0));
  CopyIfUseful(fs::path(ROOT) / "config/switch.ini", s_session.dir / "settings.ini");
  std::ofstream events(s_session.dir / "events.log", std::ios::binary | std::ios::app);
  events << "session_started\n";

  const fs::path relative = fs::relative(s_session.dir, DiagnosticsRoot(), ec);
  std::ostringstream marker;
  marker << "session_dir=" << (ec ? s_session.id : relative.generic_string()) << "\n"
         << "session_id=" << s_session.id << "\n"
         << "started_epoch=" << static_cast<long long>(s_session.started_epoch) << "\n";
  if (!WriteTextAtomic(ActiveMarker(), marker.str()))
  {
    WriteTextAtomic(s_session.dir / "summary.json",
                    SummaryJson("diagnostics_error", 0.0, "could not write active-session marker", 0));
    if (error) *error = "could not write active-session marker";
    s_session = {};
    return false;
  }
  return true;
}

void UpdateSupportClockReadings(const std::uint32_t selected_cpu_hz,
                                const std::uint32_t selected_gpu_hz,
                                const std::uint32_t effective_cpu_hz,
                                const bool effective_cpu_valid,
                                const std::uint32_t effective_gpu_hz,
                                const bool effective_gpu_valid,
                                const std::uint32_t effective_memory_hz,
                                const bool effective_memory_valid,
                                const std::string_view mechanism,
                                const std::string_view external_manager)
{
  if (!s_session.active)
    return;
  auto& m = s_session.metadata;
  m.selected_cpu_hz = selected_cpu_hz;
  m.selected_gpu_hz = selected_gpu_hz;
  m.effective_cpu_hz = effective_cpu_hz;
  m.effective_gpu_hz = effective_gpu_hz;
  m.effective_memory_hz = effective_memory_hz;
  m.effective_cpu_valid = effective_cpu_valid;
  m.effective_gpu_valid = effective_gpu_valid;
  m.effective_memory_valid = effective_memory_valid;
  m.clock_mechanism = std::string(mechanism);
  m.external_clock_manager = std::string(external_manager);
  WriteTextAtomic(s_session.dir / "summary.json", SummaryJson("running", 0.0, "", CurrentWallMs()));
}

void AppendSupportTelemetry(std::string_view report, const std::int64_t wall_ms,
                            const double guest_ms, const std::uint64_t presented_frames,
                            const int core_state)
{
  if (!s_session.active)
    return;
  {
    std::ofstream telemetry(s_session.dir / "telemetry.log", std::ios::binary | std::ios::app);
    telemetry.write(report.data(), static_cast<std::streamsize>(report.size()));
  }
  std::ostringstream checkpoint;
  checkpoint << "{\n"
             << "  \"wall_ms\": " << wall_ms << ",\n"
             << "  \"guest_ms\": " << guest_ms << ",\n"
             << "  \"presented_frames\": " << presented_frames << ",\n"
             << "  \"core_state\": " << core_state << "\n"
             << "}\n";
  WriteTextAtomic(s_session.dir / "checkpoint.json", checkpoint.str());
  WriteTextAtomic(s_session.dir / "summary.json", SummaryJson("running", guest_ms, "", wall_ms));
}

void EndSupportSession(const std::string_view status, const double guest_ms,
                       const std::string_view last_error)
{
  if (!s_session.active)
    return;
  const std::int64_t wall_ms = CurrentWallMs();
  WriteTextAtomic(s_session.dir / "summary.json", SummaryJson(status, guest_ms, last_error, wall_ms));
  {
    std::ofstream events(s_session.dir / "events.log", std::ios::binary | std::ios::app);
    events << "session_ended status=" << status << " wall_ms=" << wall_ms << " guest_ms=" << guest_ms
           << "\n";
  }
  CopyIfUseful(fs::path(ROOT) / "logs/failure-tail.log", s_session.dir / "failure-tail.log");
  CopyIfUseful(fs::path(ROOT) / "logs/crash.log", s_session.dir / "crash.log");
  std::error_code ec;
  fs::remove(ActiveMarker(), ec);
  s_session = {};
}

std::size_t PendingSupportSessionCount()
{
  std::error_code ec;
  if (!fs::is_directory(SessionsRoot(), ec))
    return 0;
  std::size_t count = 0;
  for (const auto& entry : fs::directory_iterator(SessionsRoot(), ec))
  {
    if (ec) break;
    if (entry.is_directory(ec) && !fs::exists(entry.path() / "bundled.marker", ec))
      ++count;
  }
  return count;
}

bool GenerateSupportBundle(std::string* output_path, std::string* error)
{
  FlushLog();
  std::error_code ec;
  fs::create_directories(BundlesRoot(), ec);
  if (ec)
  {
    if (error) *error = ec.message();
    return false;
  }

  std::vector<fs::path> sessions;
  if (fs::is_directory(SessionsRoot(), ec))
  {
    for (const auto& entry : fs::directory_iterator(SessionsRoot(), ec))
    {
      if (ec) break;
      if (entry.is_directory(ec) && !fs::exists(entry.path() / "bundled.marker", ec))
        sessions.push_back(entry.path());
    }
  }
  if (sessions.empty())
  {
    if (error) *error = "no new game sessions to bundle";
    return false;
  }
  std::sort(sessions.begin(), sessions.end());

  const std::time_t now = std::time(nullptr);
  const fs::path archive = BundlesRoot() / ("Phocoena-Support-" + std::to_string(static_cast<long long>(now)) + ".zip");
  void* writer = mz_zip_writer_create();
  if (!writer)
  {
    if (error) *error = "minizip writer allocation failed";
    return false;
  }
  auto cleanup = [&] { mz_zip_writer_delete(&writer); };
  if (mz_zip_writer_open_file(writer, archive.string().c_str(), 0, 0) != MZ_OK)
  {
    cleanup();
    if (error) *error = "could not create support ZIP";
    return false;
  }

  std::ostringstream manifest;
  manifest << "{\n"
           << "  \"product\": \"Phocoena\",\n"
           << "  \"version\": \"" << JsonEscape(DOLPHIN_PORT_VERSION) << "\",\n"
           << "  \"generated_epoch\": " << static_cast<long long>(now) << ",\n"
           << "  \"session_count\": " << sessions.size() << ",\n"
           << "  \"privacy\": \"No games, saves, keys, account data, or arbitrary SD files are included.\"\n"
           << "}\n";
  std::string manifest_text = manifest.str();
  mz_zip_file manifest_info{};
  manifest_info.filename = "manifest.json";
  manifest_info.compression_method = MZ_COMPRESS_METHOD_DEFLATE;
  if (mz_zip_writer_add_buffer(writer, manifest_text.data(), static_cast<int32_t>(manifest_text.size()),
                               &manifest_info) != MZ_OK)
  {
    mz_zip_writer_close(writer); cleanup();
    if (error) *error = "could not write support manifest";
    return false;
  }

  bool ok = true;
  for (const fs::path& session : sessions)
  {
    for (const auto& file : fs::recursive_directory_iterator(session, ec))
    {
      if (ec) { ok = false; break; }
      if (!file.is_regular_file(ec) || file.path().filename() == "bundled.marker")
        continue;
      const fs::path relative = fs::relative(file.path(), SessionsRoot(), ec);
      if (ec || !AddZipFile(writer, file.path(), "sessions/" + relative.generic_string()))
      {
        ok = false;
        break;
      }
    }
    if (!ok) break;
  }

  const std::vector<std::pair<fs::path, std::string>> extras = {
      {fs::path(ROOT) / "config/switch.ini", "config/switch.ini"},
      {fs::path(ROOT) / "logs/phocoena.log", "logs/phocoena.log"},
      {fs::path(ROOT) / "logs/phocoena.previous.log", "logs/phocoena.previous.log"},
      {fs::path(ROOT) / "logs/failure-tail.log", "logs/failure-tail.log"},
      {fs::path(ROOT) / "logs/crash.log", "logs/crash.log"},
      {fs::path(ROOT) / "logs/crash.previous.log", "logs/crash.previous.log"},
  };
  for (const auto& [disk, name] : extras)
  {
    if (fs::is_regular_file(disk, ec) && !AddZipFile(writer, disk, name))
    {
      ok = false;
      break;
    }
  }

  if (mz_zip_writer_close(writer) != MZ_OK)
    ok = false;
  cleanup();
  if (!ok)
  {
    fs::remove(archive, ec);
    if (error) *error = "failed while writing support ZIP";
    return false;
  }

  for (const fs::path& session : sessions)
    WriteTextAtomic(session / "bundled.marker", std::to_string(static_cast<long long>(now)) + "\n");

  if (output_path) *output_path = archive.string();
  return true;
}
}
