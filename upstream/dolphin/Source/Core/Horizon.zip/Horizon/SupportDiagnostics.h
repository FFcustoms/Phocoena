// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <cstdint>
#include <string>
#include <string_view>

namespace Horizon
{
struct SupportSessionMetadata
{
  std::string game_id;
  std::string game_name;
  std::string renderer;
  std::string cpu_mode;
  std::string shader_mode;
  std::uint32_t fifo_blocks = 1;
  std::uint32_t requested_cpu_hz = 0;
  std::uint32_t requested_gpu_hz = 0;
  std::uint32_t selected_cpu_hz = 0;
  std::uint32_t selected_gpu_hz = 0;
  std::uint32_t effective_cpu_hz = 0;
  std::uint32_t effective_gpu_hz = 0;
  std::uint32_t effective_memory_hz = 0;
  bool effective_cpu_valid = false;
  bool effective_gpu_valid = false;
  bool effective_memory_valid = false;
  std::string clock_mechanism;
  std::string external_clock_manager;
  bool memory_clock_written = false;
};

// If the previous process disappeared while a game session was active, finalize
// that record as an abnormal exit before starting another one.
void RecoverInterruptedSupportSession();

bool BeginSupportSession(const SupportSessionMetadata& metadata, std::string* error = nullptr);
void UpdateSupportClockReadings(std::uint32_t selected_cpu_hz, std::uint32_t selected_gpu_hz,
                                std::uint32_t effective_cpu_hz, bool effective_cpu_valid,
                                std::uint32_t effective_gpu_hz, bool effective_gpu_valid,
                                std::uint32_t effective_memory_hz, bool effective_memory_valid,
                                std::string_view mechanism, std::string_view external_manager);
void AppendSupportTelemetry(std::string_view report, std::int64_t wall_ms, double guest_ms,
                            std::uint64_t presented_frames, int core_state);
void EndSupportSession(std::string_view status, double guest_ms, std::string_view last_error);

// Creates one ZIP containing every not-yet-bundled session plus the current
// Phocoena logs/config. Games, saves, keys and arbitrary SD files are never added.
bool GenerateSupportBundle(std::string* output_path, std::string* error = nullptr);
std::size_t PendingSupportSessionCount();
}
